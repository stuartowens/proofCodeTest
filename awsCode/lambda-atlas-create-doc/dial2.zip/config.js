"use strict";

var config = {
    "templateKey" : "templates/contactEmail.html",
    "defaultSubject" : "Contact form submission from Dialword"
}

module.exports = config
