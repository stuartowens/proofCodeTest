"use strict";

var config = {
    "templateKey" : "Templates/Restaurants.html",
    "defaultSubject" : "Your list of restaurants"
}

module.exports = config
